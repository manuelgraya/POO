#include "pedido-articulo.hpp"


LineaPedido::LineaPedido(double precioVenta, unsigned cantidad) : precioVenta_{precioVenta}, cantidadVendida_{cantidad} {};

ostream& operator <<(ostream& os, const LineaPedido& lineaPedido)
{
    os <<setprecision(2)<<fixed<<lineaPedido.precio_venta()<<" €\t"<<lineaPedido.cantidad()<<endl;
    return os;
}

void Pedido_Articulo::pedir(Pedido& pedido, Articulo& articulo, double precio, unsigned cantidad)
{
    Ped_Art[&pedido].insert(make_pair(&articulo, LineaPedido(precio, cantidad)));
    Inv_Ped_Art[&articulo].insert(make_pair(&pedido, LineaPedido(precio, cantidad)));
}

void Pedido_Articulo::pedir(Articulo& articulo, Pedido& pedido, double precio, unsigned cantidad)
{
    pedir(pedido, articulo, precio, cantidad);
}

const Pedido_Articulo::ItemsPedido Pedido_Articulo::detalle(Pedido& ped) const
{
    map<Pedido*, ItemsPedido, OrdenaPedidos>::const_iterator i = Ped_Art.find(&ped);

    if (i != Ped_Art.end())
    {
        return i->second;
    }
    else
    {
        return ItemsPedido();
    }

}

const Pedido_Articulo::Pedidos Pedido_Articulo::ventas(Articulo& art) const
{
    map<Articulo*, Pedidos, OrdenaArticulos>::const_iterator i = Inv_Ped_Art.find(&art);

    if (i != Inv_Ped_Art.end())
    {
        return i->second;
    }
    else
    {
        return Pedidos();
    }
}

ostream& operator <<(ostream& os, const Pedido_Articulo::ItemsPedido& iPed)
{
    double n_totalItems=0;
    unsigned int cant=0;
    os <<"  PVP   Cantidad        Artículo"<<endl;
    os <<"=================================================================="<<endl;
    for (auto iter : iPed)
    {
        os << fixed<<setprecision(2) <<iter.second.precio_venta()<<" € "<<iter.second.cantidad()<<"               "<<"["<<iter.first->referencia()<<"]"<<"  "<<"\""<<iter.first->titulo()<<"\""<<endl;
        n_totalItems += iter.first->precio();
        cant += iter.second.cantidad();
    }
    os <<"=================================================================="<<endl;
    os <<"Total:    "<<fixed<<setprecision(2) <<n_totalItems<< " €"<<"       " << cant<<endl;
    
    return os;
}

ostream& operator <<(ostream& os, const Pedido_Articulo::Pedidos& ped1)
{
    double total = 0;
    unsigned int cantidad= 0;
    os <<" [Pedidos: "<<ped1.size()<<"]"<<endl;
    os <<"=================================================================="<<endl;
    os <<"  PVP    Cantidad        Fecha de venta"<<endl;
    os <<"=================================================================="<<endl;
    for (auto iter : ped1)
    {
        total+=iter.second.precio_venta()*iter.second.cantidad();
        os <<fixed<<setprecision(2)<< iter.second.precio_venta()<<" € "<< iter.second.cantidad()<<"          " << iter.first->fecha()<<endl;
        cantidad+= iter.second.cantidad();
    }
    os <<"=================================================================="<<endl;
    os <<fixed<<setprecision(2)<<total<<" €"<<"         "<<cantidad<<endl;
    
    return os;
}

//Flujo de insercion para mostrar los detalles de los pedidos
void Pedido_Articulo::mostrarDetallePedidos(ostream& os) const
{
    double total=0;
    for (auto iter : Ped_Art)
    {
        os <<"Pedido num. "<< iter.first->numero()<<endl;
        os <<"Cliente: " <<iter.first->tarjeta()->titular()->nombre()<<"         " << "Fecha: " <<iter.first->fecha() << endl;
        os << detalle(*iter.first) << endl;
        total += iter.first->total();
    }
    os << "TOTAL VENTAS         "<<fixed<<setprecision(2)<< total<< " €" << endl;
}

//Flujo de insercion para mostrar las ventas de los articulos
void Pedido_Articulo::mostrarVentasArticulos(ostream& os) const
{
    for (auto iter : Inv_Ped_Art)
    {
        os << "Ventas de ["<< iter.first->referencia()<<"] "<< "\"" <<iter.first->titulo() << "\"";
        os << ventas(*iter.first) <<endl;
    }
}
