#ifndef PEDIDO_ARTICULO__HPP__
#define PEDIDO_ARTICULO__HPP__
#include "articulo.hpp"
#include "pedido.hpp"
#include<iomanip>
#include<map>
#include<iostream>
using namespace std;

class Pedido;

class LineaPedido{
    public:
        explicit LineaPedido(double precioVenta = 0.0, unsigned cantidad = 1);
        unsigned cantidad() const { return cantidadVendida_;}
        double precio_venta() const { return precioVenta_;}

    private:
        double precioVenta_;
        unsigned cantidadVendida_;
};

ostream& operator <<(ostream& os, const LineaPedido& lineaPedido);



class Pedido_Articulo {
    public:       
        class OrdenaArticulos {
            public:
                bool operator() (const Articulo* art1, const Articulo* art2) const{
                    return art1->referencia() < art2->referencia();
                }
        };

        class OrdenaPedidos {
            public:
                bool operator() (const Pedido* ped1, const Pedido* ped2) const {
                    return ped1->numero() < ped2->numero();
                }
        };
        
        typedef std::map<Articulo*, LineaPedido, OrdenaArticulos> ItemsPedido;
        typedef std::map<Pedido*, LineaPedido, OrdenaPedidos> Pedidos;

        void pedir(Pedido& pedido, Articulo& articulo, double precio, unsigned cantidad = 1);
        void pedir(Articulo& articulo, Pedido& pedido, double precio, unsigned cantidad = 1);        

        const ItemsPedido detalle(Pedido& ped) const;
        const Pedidos ventas(Articulo& art) const;

        
        void mostrarDetallePedidos(ostream& os) const;
        void mostrarVentasArticulos(ostream& os) const;


    private:
        std::map<Pedido*, ItemsPedido, OrdenaPedidos> Ped_Art;
        std::map<Articulo*, Pedidos, OrdenaArticulos> Inv_Ped_Art;
};

ostream& operator <<(ostream& os, const Pedido_Articulo::ItemsPedido& ped);

ostream& operator <<(ostream& os, const Pedido_Articulo::Pedidos& art);


#endif
