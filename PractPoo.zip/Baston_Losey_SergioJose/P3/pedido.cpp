#include "pedido.hpp"

int Pedido::N_pedidos = 1;


Pedido::Pedido(Usuario_Pedido& user_pedido, Pedido_Articulo& pedido_articulo, Usuario& user, const Tarjeta& tarjet, const Fecha& fech) : numero_{N_pedidos}, tarjetaPed_{&tarjet}, fechaPed_{fech}, importeTotPed_{0}
{

    if (tarjetaPed_->titular()!=&user)
    {
        throw Impostor(&user);
    }

    if (tarjetaPed_->caducidad() < fechaPed_)
    {
        throw Tarjeta::Caducada(tarjetaPed_->caducidad());
    }

    if (!tarjetaPed_->activa())
    {
        throw Tarjeta::Desactivada();
    }

    if(user.compra().size() == 0)
    {
        throw Vacio(&user);
    }

    for (auto it : user.compra())
    {
        if (it.first->stock() < it.second)
        {
            user.vaciar_carro();
            throw SinStock(*it.first);
        }
    }

    //Dentro del carrito vamos a actualizarlo e ir viendo los articulos que va a comprar el usuario
    //generando el pedido
    for (auto iter=user.compra().begin(); iter != user.compra().end(); ++iter)
    {
        Articulo& art = *iter->first;
        unsigned cantidad= iter->second;
        pedido_articulo.pedir(art, *this, art.precio(), cantidad);
        importeTotPed_+= art.precio()* cantidad;
        art.stock()-= cantidad;
    }

    //Asociamos el pedido al usuario
    user_pedido.asocia(user, *this);
    //Vaciamos el carrito despues de generar el pedido
    user.vaciar_carro();
    //Incrementamos el numero de pedidos
    numero_=N_pedidos++;
}

//Flujo de insercion de Pedido
ostream& operator <<(ostream& os, const Pedido& p1)
{
    os <<"Núm. pedido: "<<p1.numero()<<endl;
    os <<"Fecha:       "<<p1.fecha()<<endl;
    os <<"Pagado con:  "<<p1.tarjeta()->tipo()<<"n.º: "<<p1.tarjeta()->numero()<<endl;
    os <<"Importe:     "<<fixed << setprecision(2)<<p1.total() << " €"<<endl;

    return os;
};

// Pedido::Pedido(Usuario_Pedido& usu_ped_, Pedido_Articulo& ped_art_, Usuario& u, const Tarjeta& t, const Fecha& fp) 
// {
//     //PASO 1: vacio, impostor, caducada y desactivada
//     //PASO 2: recorrido del carro -> Sin Stock

//     //PASO 3: recorrido del carro -> facturar (a partir de aquí no se producirían más excepciones)
//     //3.1: enlace entre Pedido y Artículo
//     //3.2: actualizar el importe total
//     //3.3: reducir stock
//     //3.4: vaciar el carro
//     //PASO 4: asociación Pedido y Usuario
//     //PASO 5: AUMENTAR NÚMERO DE PEDIDO
//     //VARIABLE STATIC PARA IR INCREMENTANDO    
// }