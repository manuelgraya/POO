#ifndef USUARIO_PEDIDO__HPP_
#define USUARIO_PEDIDO__HPP_
#include<map>
#include "pedido.hpp"
#include "usuario.hpp"
#include<iostream>
using namespace std;

class Pedido;

class Usuario_Pedido
{
    public:
        typedef set<Pedido*> Pedidos;
        void asocia(Usuario& user, Pedido& ped);
        void asocia(Pedido& ped, Usuario& user);
        const Pedidos pedidos(Usuario& user) const;
        const Usuario* cliente(Pedido& ped) const;
    private:
        map<Pedido*, Usuario*> Inv_Usuario_Pedidos;
        map<Usuario*, Pedidos> Usuario_Pedidos;
};


#endif