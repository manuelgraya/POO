#include "usuario-pedido.hpp"

const Usuario_Pedido::Pedidos Usuario_Pedido::pedidos(Usuario& user) const
{
    map<Usuario*, Pedidos>::const_iterator i = Usuario_Pedidos.find(&user);

    if (i != Usuario_Pedidos.end())
    {
        return i->second;
    }
    else
    {
        return Pedidos();
    }
}

const Usuario* Usuario_Pedido::cliente(Pedido& ped) const
{
    auto it = Inv_Usuario_Pedidos.find(&ped);
    
    if (it != Inv_Usuario_Pedidos.end())
    {
        return it->second;
    }
    else
    {
        return nullptr;
    }
}


void Usuario_Pedido::asocia(Usuario& user, Pedido& ped)
{
    Inv_Usuario_Pedidos.insert(make_pair(&ped, &user));  //map<Ejem1*, Ejem2*>
    Usuario_Pedidos[&user].insert(&ped);   //map<Ejem*, set<>>
}



void Usuario_Pedido::asocia(Pedido& ped, Usuario& user)
{
    asocia(user, ped);
}