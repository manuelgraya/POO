#include <iostream>
using namespace std;
struct A {
    void mostrar(int i) { cout << i << " [A-entero]" << endl; }
    void mostrar(float f) { cout << f << " [A-real]" << endl; }
};
struct B: A {
    void mostrar(float f) { cout << f << " [B-real]" << endl; }
};

int main()
{
    A a;
    B b;
    a.mostrar(4);
    a.mostrar((float)4.1);
    b.mostrar(4);
    b.mostrar(4.1);
}
