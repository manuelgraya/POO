#ifndef PEDIDO__HPP_
#define PEDIDO__HPP_
#include "tarjeta.hpp"
#include "usuario-pedido.hpp"
#include "pedido-articulo.hpp"
#include<iostream>
using namespace std;


class Articulo;
class Usuario;
class Fecha;
class Usuario_Pedido;
class Pedido_Articulo;

class Pedido
{
    public:
        Pedido(Usuario_Pedido& usu_ped_, Pedido_Articulo& ped_art_, Usuario& u, const Tarjeta& t, const Fecha& fp = Fecha());

        class Vacio{
            public:
                Vacio(const Usuario* user) : user_{user} {}
                const Usuario& usuario() const { return *user_;}
            private:
                const Usuario* user_;
        };

        class Impostor{
            public:
                Impostor(const Usuario* user) : user_{user} {}
                const Usuario& usuario() const { return *user_;}
            private:
              const Usuario* user_;  
        };

        class SinStock{
            public:
                SinStock(const Articulo& art) : art_{&art} {}
                const Articulo& articulo() const {return *art_;}
            private:
                const Articulo* art_;
        };

        int numero() const { return numero_;};
        const Tarjeta* tarjeta() const { return tarjetaPed_;};
        const Fecha& fecha() const { return fechaPed_;};
        double total() const { return importeTotPed_;};
        static int n_total_pedidos() { return N_pedidos;}

    private:
        static int N_pedidos;
        int numero_;
        const Tarjeta* tarjetaPed_;
        Fecha fechaPed_;
        double importeTotPed_;
};

ostream& operator <<(ostream& os, const Pedido& ped);

#endif