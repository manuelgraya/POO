#include<iostream>
#include "fecha.hpp"

int main()
{
    Fecha a;
    cout<< "El día de hoy es: " << a.dia()<<endl;
}