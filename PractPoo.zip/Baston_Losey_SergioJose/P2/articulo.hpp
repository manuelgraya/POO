#ifndef ARTICULO_HPP__
#define ARTICULO_HPP__
#include<iostream>
#include<iomanip>
#include "../P1/cadena.hpp"
#include "../P1/fecha.hpp"
using namespace std;

class Articulo{
    public:
        Articulo(Cadena codigoRef, Cadena titulo, Fecha fechaPublic, double precio, unsigned numEjemplar = 0);
        const Cadena referencia() const;
        const Cadena titulo() const;
        const Fecha f_publi() const;
        double precio() const;
        double& precio();
        unsigned stock() const;
        unsigned& stock();
    private:
        const Cadena codigoRef_;
        const Cadena titulo_;
        const Fecha fechaPublic_;
        double precio_;
        unsigned numEjemplar_;

};

ostream& operator <<(ostream& os, const Articulo& art);

inline const Cadena Articulo::referencia() const
{
    return codigoRef_;
}

inline const Cadena Articulo::titulo() const
{
    return titulo_;
}

inline const Fecha Articulo::f_publi() const
{
    return fechaPublic_;
}

inline double Articulo::precio() const
{
    return precio_;
}

inline double& Articulo::precio() 
{
    return precio_;
}

inline unsigned Articulo::stock() const
{
    return numEjemplar_;
}

inline unsigned& Articulo::stock()
{
    return numEjemplar_;
}


#endif