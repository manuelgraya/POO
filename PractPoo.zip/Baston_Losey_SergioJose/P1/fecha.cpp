#include "fecha.hpp"

//Constructor general de FECHA
Fecha::Fecha(int dia, int mes, int anno) : dia_(dia), mes_(mes), anno_(anno), actual(false)
{
    if (dia != 0 && mes != 0 && anno != 0)
    {
        valida();
    }
    else
    {
        time_t tiempo_calendario = time(nullptr);
        tm* tiempo_descompuesto = localtime(&tiempo_calendario);
        if (dia_ == 0)
        {
            dia_ = tiempo_descompuesto->tm_mday;
        }
        if (mes_ == 0)
        {
            mes_ = tiempo_descompuesto->tm_mon + 1;
        }
        if (anno_ == 0)
        {
            anno_ = tiempo_descompuesto->tm_year + 1900;
        }

        valida();
    }
}

//Constructor de cadena de caracteres
Fecha::Fecha(const char* Fech)
{
    int dia, mes, anno;
    if (sscanf(Fech, "%d/%d/%d", &dia, &mes, &anno) != 3)
    {
        throw Fecha::Invalida("Formato de fecha no válido");
    }
    
    Fecha f(dia, mes, anno);
    dia_ = f.dia();
    mes_ = f.mes();
    anno_ = f.anno();
    actual = f.actual;
}

//Método para saber si el anno es bisiesto
bool Fecha::AnnoBisiesto(int anno) const
{
    if ((anno % 4 == 0 && anno % 100 != 0) || anno % 400 == 0)
    {
        return true;
    }
    else
    {
        return false;
    }
}

//Método privado valida()
void Fecha::valida() const
{
    if (dia_ < 1)
    {
        throw Fecha::Invalida("Día inválido");
    }
    if (mes_ < 1 || mes_ > 12)
    {
        throw Fecha::Invalida("Mes fuera de rango");
    }
    if (dia_ > 31 && (mes_ == 1 || mes_ == 3 || mes_ == 5 || mes_ == 7 || mes_ == 8 || mes_ == 10 || mes_ == 12))
    {
        throw Fecha::Invalida("Día fuera de rango en los meses correspondientes");
    }
    if (dia_ > 30 && (mes_ == 4 || mes_ == 6 || mes_ == 9 || mes_ == 11 ))
    {
        throw Fecha::Invalida("Día fuera de rango en los meses correspondientes");
    }
    if (AnnoBisiesto(anno_) && mes_ == 2 && dia_ > 29)
    {
        throw Fecha::Invalida("Anno Bisiesto fuera de rango");
    }
    if (!AnnoBisiesto(anno_) && mes_ == 2 && dia_ > 28)
    {
        throw Fecha::Invalida("Anno No Bisiesto fuera de rango");
    }
    if (anno_ < Fecha::AnnoMinimo || anno_ > Fecha::AnnoMaximo)
    {
        throw Fecha::Invalida("Anno fuera de límite");
    }
}

istream& operator >>(istream& is, Fecha& f)
{
    char fecha[11];
    is.getline(fecha, 11);
    try {
        f = Fecha(fecha);
    }catch (const Fecha::Invalida& e)
    {
        is.setstate(ios::failbit);
        throw e;
    }

    return is;
}

ostream& operator <<(ostream& os, const Fecha& f)
{
    os << f.cadena();
    return os;
}
//Operadores aritméticos
//Operador aritmético de suma con asignación
Fecha& Fecha::operator +=(int n)
{
    struct tm fechaStruct = {};
    fechaStruct.tm_year = anno_ - 1900;
    fechaStruct.tm_mon = mes_ - 1;
    fechaStruct.tm_mday = dia_ + n;

    mktime(&fechaStruct);

    this->dia_ = fechaStruct.tm_mday;
    this->mes_ = fechaStruct.tm_mon + 1;
    this->anno_ = fechaStruct.tm_year + 1900;
    valida();
    return *this;
}

//Operador aritmético de resta
Fecha& Fecha::operator -=(int n)
{
    *this += -n;
    return *this;
}

//Operador de suma aritmética
Fecha Fecha::operator +(int n) const
{
    Fecha f(*this);
    f += n;
    return f;
}

//Operador de resta aritmética
Fecha Fecha::operator -(int n) const
{
    Fecha f(*this);
    f += -n;
    return f;
}

//Operador de preincremento de suma
Fecha& Fecha::operator ++()
{
    *this += 1;
    return *this;
}

//Operador de preincremento de resta
Fecha& Fecha::operator --()
{
    *this += -1;
    return *this;
}

//Operador de postincremento de suma
Fecha Fecha::operator ++(int)
{
    Fecha fech(*this);
    *this += 1;
    return fech;
}

//Operador de postincremento de resta
Fecha Fecha::operator --(int)
{
    Fecha fech(*this);
    *this += -1;
    return fech;
}

//Método privado para la conversión de la cadena
void Fecha::actualizaCadena() const
{
    locale::global(std::locale("es_ES.UTF-8")); //establece el locale español
    struct tm fechaStruct = {};
    fechaStruct.tm_year = anno_ - 1900;
    fechaStruct.tm_mon = mes_ - 1;
    fechaStruct.tm_mday = dia_;

    mktime(&fechaStruct);
    strftime(crep, sizeof(crep), "%A %d de %B de %Y", &fechaStruct);
}
//Sobrecarga del operadores const char*
const char* Fecha::cadena() const
{
    if (!actual)
    {
        actualizaCadena();
        actual = true;
    }
    return crep;
}


//Operadores de comparación
bool operator ==(const Fecha& f1, const Fecha& f2)
{
    return (f1.anno() == f2.anno() && f1.mes() == f2.mes() && f1.dia() == f2.dia());
}

bool operator <(const Fecha& f1, const Fecha& f2)
{
    return ((f1.anno() < f2.anno()) || (f1.anno() == f2.anno() && f1.mes() < f2.mes()) || (f1.anno() == f2.anno() && f1.mes() == f2.mes() && f1.dia() < f2.dia()));
}

bool operator !=(const Fecha& f1, const Fecha& f2)
{
    return !(f1 == f2);
}

bool operator >(const Fecha& f1, const Fecha& f2)
{
    return (f2 < f1);
}

bool operator >=(const Fecha& f1, const Fecha& f2)
{
    return !(f1 < f2);   //Si f1 no ! es menor que f2 entonces es que es mayor o igual que f2 por descarte
}

bool operator <=(const Fecha& f1, const Fecha& f2)
{
    return !(f2 < f1);
}