#include<iostream>
using namespace std;
class Complejo
{
    public:
        Complejo(double r_ = 0, double i_ = 1) : r(r_), i(i_) {};
        double rjeje() const {return r;};
        double ijeje() const {return i;};
    private:
        double r, i;
};

int main()
{
    // Complejo x(2, -1.2);
    // cout << x.rjeje() << "    "<< x.ijeje()<<endl;
    // x = -3.5;
    // cout << x.rjeje() <<"     " <<x.ijeje()<<endl;
    int a;
    cout<<"Introduce un numero del 1 al 10: "<<endl;
    cin >> a;
    switch(a)
    {
        case 1:
            cout <<"Eres Guapa";
            break;
        case 2:
            cout <<"Eres Guapa";
            break;
        case 3:
            cout <<"Me la come de pie";
            break;
        case 4:
            cout <<"Me agarra la picha un rato";
            break;
        case 5:
            cout <<"Por el culo te la hinco";
            break;
        case 6:
            cout <<"Eres Guapa";
            break;
        case 7:
            cout <<"Por el culo se te mete";
            break;
        case 8:
            cout <<"Me come todo el chocho";
            break;
        case 9:
            cout <<"Por el culo se te mueve";
            break;
        case 10:
            cout <<"Eres Guapa";
            break;
        default:
            cout << "Eres gilipollas, espabila";
            break;
    }
    return 0;
}

