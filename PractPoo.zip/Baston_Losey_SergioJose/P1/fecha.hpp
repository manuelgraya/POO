#ifndef FECHA_HPP_
#define FECHA_HPP_
#include<iostream>
#include<cstdio>
#include<ctime>
using namespace std;

class Fecha{
    public:
        static const int AnnoMinimo = 1902;
        static const int AnnoMaximo = 2037;
        explicit Fecha(int dia = 0, int mes = 0, int anno = 0);
        Fecha(const char* fech);
        class Invalida{
            public:
                Invalida(const char* e) : e_(e){}
                const char* por_que() const{
                    return e_;
                }
            private:
                const char* e_;
        };
        Fecha& operator +=(int n);
        Fecha& operator -=(int n);
        Fecha operator +(int n) const;
        Fecha operator -(int n) const;
        Fecha& operator ++();
        Fecha& operator --();
        Fecha operator --(int);
        Fecha operator ++(int);
        const char* cadena() const;
        int dia() const noexcept;  //Como es básico, no es necesario hacer que no devuelva una copia
        int mes() const noexcept;
        int anno() const noexcept;
        bool AnnoBisiesto(int anno) const; 
    private:
        int dia_, mes_, anno_;
        mutable char crep[80];
        mutable bool actual;
        void actualizaCadena() const;
        void valida() const;  //Se pone en la parte privada para que el usuario no vea ese método (principio de ocultación)
};

istream& operator >>(istream& is, Fecha& f);
ostream& operator <<(ostream& os, const Fecha& f);
bool operator ==(const Fecha& f1, const Fecha& f2);
bool operator <(const Fecha& f1, const Fecha& f2);
bool operator !=(const Fecha& f1, const Fecha& f2);
bool operator >(const Fecha& f1, const Fecha& f2);
bool operator >=(const Fecha& f1, const Fecha& f2);
bool operator <=(const Fecha& f1, const Fecha& f2);


inline int Fecha::dia() const noexcept{
    return dia_;
}

inline int Fecha::mes() const noexcept{
    return mes_;
}

inline int Fecha::anno() const noexcept{
    return anno_;
}

#endif