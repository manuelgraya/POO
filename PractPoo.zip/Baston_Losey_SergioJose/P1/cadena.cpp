#include "cadena.hpp"

//Inicializar la variable vacia[1] en el cpp de Cadena
char Cadena::vacia[1] = {'\0'};

//Constructor general
Cadena::Cadena(size_t tam, char a) : tam_(tam)
{
    if (tam == 0)
    {
        s_ = vacia;
    }
    else
    {
        s_ = new char[tam + 1];
        for (size_t i = 0; i < tam; i++)
        {
            s_[i] = a;
        }
        s_[tam_] = vacia[0];
    }
    

}

//Constructor de copia
Cadena::Cadena(const Cadena& cad) : tam_(cad.tam_)
{
    if(tam_ == 0)
    {
        s_ = vacia;
    }
    else
    {
        s_ = new char[tam_ + 1];
        strcpy(s_, cad.s_);
        s_[tam_ + 1] = vacia[0];
    }

}


//Constructor de const char* a Cadena (conversión)
Cadena::Cadena(const char* cad)
{
    tam_ = strlen(cad);
    s_ = new char[tam_ + 1];
    strcpy(s_, cad);
    s_[tam_ + 1] = vacia[0];
}


//Sobrecarga del operador de asignación de copia
Cadena& Cadena::operator =(const Cadena& otra)
{
    if (this != &otra)
    {

        if (tam_ > 0)
        {
            delete[] s_;
        }

        tam_ = otra.tam_;
        if (otra.tam_ > 0)
        {
            
            s_ = new char[tam_ + 1];
            strcpy(s_, otra.s_);
            s_[tam_ + 1] = vacia[0];
        }
        else{

            s_ = vacia;
        }
       
    }
    return *this;
}

//Sobrecarga del operador de asignación para const char* ()
Cadena& Cadena::operator=(const char* cad)
{
    if (s_ != cad)
    {
        if (tam_ > 0)
        {
            delete[] s_;
        }

        tam_ = strlen(cad);

        s_ = new char[tam_ + 1];
        strcpy(s_, cad);
        s_[tam_] = '\0';
    }

    return *this;
}

//Sobrecarga del operador const char* () (parece método observador)
Cadena::operator const char *() const
{
    return s_;
}

//Método observador del tamanno de la cadena
size_t Cadena::length() const
{
    return tam_;
}

//Constructor de movimiento
Cadena::Cadena(Cadena&& cad) : tam_(cad.tam_)
{
    s_ = cad.s_;
    cad.tam_ = 0;
    cad.s_ = vacia;
}

//Operador de asignación de movimiento
Cadena& Cadena::operator=(Cadena&& cad)
{
    if (this != &cad)
    {
        if (tam_ > 0)
        {
            delete [] s_;
            tam_ = cad.tam_;
            s_ = cad.s_;
            cad.tam_ = 0;
            cad.s_ = vacia;
        }

    }

    return *this;
}

istream& operator >>(istream& is, Cadena& cad)
{
    char buffer[33] = "";
    is.width(33);
    is >> buffer;
    cad = buffer;
    return is;
}

ostream& operator <<(ostream& os, const Cadena& cad)
{
    os << cad.s_;
    return os;
}

Cadena& Cadena::operator +=(const Cadena& c)
{
    if (tam_ > 0)
    {
        char* nuevo = new char[tam_ + c.length() + 1];
        strcpy(nuevo, s_);
        strcat(nuevo, c.s_);
        tam_ += c.tam_;
        delete [] s_;
        s_ = new char[tam_ + 1];
        strcpy(s_, nuevo);
        s_[tam_]= '\0';
        delete[] nuevo;
    }
    else
    {
        char* nuevo = new char[tam_ + c.length() + 1];
        strcpy(nuevo, s_);
        strcat(nuevo, c.s_);
        tam_ += c.tam_;
        s_ = new char[tam_ + 1];
        strcpy(s_, nuevo);
        s_[tam_]= '\0';
        delete[] nuevo;
    }

    return *this;
}

Cadena operator +(const Cadena& c1, const Cadena& c2)
{
    Cadena c(c1);
    c += c2;
    return c;
}

//Operadores de comparación lógico
//Operador de igualdad
bool operator ==(const Cadena& Cad1, const Cadena& Cad2)
{
    return (strcmp(Cad1.s_, Cad2.s_) == 0);
}

//Operador de desigualdad
bool operator !=(const Cadena& Cad1, const Cadena& Cad2)
{
    return !(Cad1 == Cad2);
}

//Operador de mayor que
bool operator >(const Cadena& Cad1, const Cadena& Cad2)
{
    return (strcmp(Cad1.s_, Cad2.s_) > 0);
}

//Operador de menor que
bool operator <(const Cadena& Cad1, const Cadena& Cad2)
{
    return (strcmp(Cad1.s_, Cad2.s_) < 0);
}

//Operador de mayor o igual que
bool operator >=(const Cadena& Cad1, const Cadena& Cad2)
{
    return !(Cad1 < Cad2);
}

//Operador de menor o igual que
bool operator <=(const Cadena& Cad1, const Cadena& Cad2)
{
    return !(Cad1 > Cad2);
}

//Sobrecarga del operador [] para const
char& Cadena::operator [](size_t index) const
{
    return s_[index];
}

//Sobrecarga del operador [] para no const (modificables)
char& Cadena::operator [](size_t index)
{
    return s_[index];
}

//Método que controla las excepciones para const
char& Cadena::at(size_t index) const
{
    if (index >= tam_)
    {
        throw out_of_range("Indice fuera de limite");
    }

    return s_[index];
}

//Método que controla las excepciones para no const (modificables)
char& Cadena::at(size_t index)
{
    if (index >= tam_)
    {
        throw out_of_range("Indice fuera de limite");
    }
    
    return s_[index];
}

//Método substr para devolver una subCadena especificado
Cadena Cadena::substr(unsigned index, size_t tama) const
{
    if (index > tam_  || tama > tam_ || index + tama > tam_)
    {
        throw out_of_range("Indice fuera de limite");
    }
    Cadena subCadena(tama);
    for (size_t i = 0; i < tama; ++i)
    {
        subCadena[i] = s_[i + index];
    }
    subCadena[tama] = vacia[0];
    return subCadena;
}

//Destructor de Cadena (utiliza memoria dinámica)
Cadena::~Cadena()
{
    if (tam_ > 0)
    {
        delete [] s_;
    }
}