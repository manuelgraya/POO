#ifndef ARTICULO_HPP__
#define ARTICULO_HPP__
#include<iostream>
#include<iomanip>
#include "../P1/cadena.hpp"
#include "../P1/fecha.hpp"
#include<set>
using namespace std;

class Autor {
    public:
        Autor(Cadena nombre, Cadena apellidos, Cadena direccion) : nombre_{nombre}, apellidos_{apellidos}, direccion_{direccion} {};
        const Cadena nombre() const { return nombre_;}
        const Cadena apellidos() const { return apellidos_;}
        const Cadena direccion() const { return direccion_;}
    private:
        Cadena nombre_;
        Cadena apellidos_;
        Cadena direccion_;
};

class Articulo{  //Clase Abstracta
    public:
        typedef set<Autor*> Autores;

        class Autores_vacios{
            public:
                Autores_vacios();
        };

        virtual void impresion_especifica(ostream& os) const = 0;
        virtual ~Articulo(){};

        const Cadena referencia() const;
        const Cadena titulo() const;
        const Fecha f_publi() const;
        double precio() const;
        double& precio();
        const Autores& autores() const noexcept { return autores_;}
        
    protected:
        Articulo(const Autores autores, Cadena codigoRef, Cadena titulo, Fecha fechaPublic, double precio);
    
    private:
        const Cadena codigoRef_;
        const Cadena titulo_;
        const Fecha fechaPublic_;
        double precio_;
        const Autores autores_;

};

ostream& operator <<(ostream& os, const Articulo& art);

inline const Cadena Articulo::referencia() const
{
    return codigoRef_;
}

inline const Cadena Articulo::titulo() const
{
    return titulo_;
}

inline const Fecha Articulo::f_publi() const
{
    return fechaPublic_;
}

inline double Articulo::precio() const
{
    return precio_;
}

inline double& Articulo::precio() 
{
    return precio_;
}

class ArticuloAlmacenable: public Articulo {
    public:
        ArticuloAlmacenable(const Autores autores, Cadena codigoRef, Cadena titulo, Fecha fechaPublic, double precio, unsigned stock = 0) : Articulo(autores, codigoRef, titulo, fechaPublic, precio), stock_{stock} {};
        unsigned stock() const { return stock_;}
        unsigned& stock() { return stock_;}
    private:
        unsigned stock_;
};

class Libro final: public ArticuloAlmacenable {
    public:
        Libro(const Autores autores, Cadena codigoRef, Cadena titulo, Fecha fechaPublic, double precio,unsigned int pagina, unsigned stock = 0) : ArticuloAlmacenable(autores, codigoRef, titulo, fechaPublic, precio, stock), n_pag_{pagina} {};
        const unsigned int n_pag() const { return n_pag_;}
        void impresion_especifica(ostream& os) const;
    private:
        unsigned int n_pag_;
};

class Revista final: public ArticuloAlmacenable {
    public:
        Revista(const Autores autores, Cadena codigoRef, Cadena titulo, Fecha fechaPublic, double precio, int numero, int dias, unsigned stock = 0) : ArticuloAlmacenable(autores, codigoRef, titulo, fechaPublic, precio, stock), numero_{numero}, dias_{dias} {};
        const int numero() const { return numero_;}
        const int periodicidad() const { return dias_;}
        void impresion_especifica(ostream& os) const;
    private:
        int numero_;
        int dias_;
};

class LibroDigital final: public Articulo {
    public:
        LibroDigital(const Autores autores, Cadena codigoRef, Cadena titulo, Fecha fechaPublic, double precio, const Fecha FechaExpiracion) : Articulo(autores, codigoRef, titulo, fechaPublic, precio), fechaExpiracion_{FechaExpiracion} {};
        const Fecha& f_expir() const noexcept { return fechaExpiracion_;}
        void impresion_especifica(ostream& os) const;
    private:
        const Fecha fechaExpiracion_;
};


#endif