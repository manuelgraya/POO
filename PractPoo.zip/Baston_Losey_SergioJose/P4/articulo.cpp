#include "articulo.hpp"

Articulo::Articulo(const Autores autores, Cadena codigoRef, Cadena titulo, Fecha fechaPublic, double precio) : autores_{autores}, codigoRef_{codigoRef}, titulo_{titulo}, fechaPublic_{fechaPublic}, precio_{precio} {
    if (autores_.empty())
    { 
        throw Autores_vacios();
    }
}

//Flujo de inserción de un Artículo
ostream& operator <<(ostream& os, const Articulo& Artic)
{
    os <<"["<<Artic.referencia()<<"] \""<<Artic.titulo()<<"\", de ";
    auto iter = Artic.autores().begin();
    os << (*iter)->apellidos();  //Imprimimos el primer apellido
    iter++;
    while(iter!=Artic.autores().end())  //Imprimimos los demás apellidos
    {
        os<<", " << (*iter)->apellidos();
        iter++;
    }
    os <<". "<<Artic.f_publi().anno() <<". "<< setprecision(2) <<fixed <<Artic.precio() << " €"<<endl;
    os << "\t";
    Artic.impresion_especifica(os);  //Impresión específica de las clases heredadas
    return os;
}

//Impresión específica Libro
void Libro::impresion_especifica(ostream& os) const
{
    os <<  n_pag() << " págs., "<<stock() << " unidades.";
}
//Impresión específica Revista
void Revista::impresion_especifica(ostream& os) const
{
    os << "Número: "<< numero() <<", Periodicidad: "<< periodicidad() << " días."<<endl;
    os <<"\t"<< "Próximo número a partir de: "<< f_publi() + periodicidad()<< ".";
}
//Impresión específica LibroDigital
void LibroDigital::impresion_especifica(ostream& os) const
{
    os << "A la venta hasta el "<< f_expir() << ".";
}